package com.example.driver

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
